Candy World Icons - Free Demo

Contents
- 40 unique designs: 30 candy-world items and 10 matching UI graphics.
- Each design is supplied in color and grayscale: 80 image variants.
- Individual static 256 x 256 pixel, 8-bit RGBA PNG images with transparency.
- 40 categories, 1 design(s) per category.
- Each variant appears in two organizational views: 160 PNG files plus
  README.txt, PREVIEW.txt and LICENSE.txt; 163 files total.

The collection covers sweets, chocolate, baked goods, ice cream, drinks, ingredients,
baking tools, candy containers, sugar plants, resources, buildings, world props,
machines, vehicles, tools, gear, creatures, boosts, currencies and rewards,
plus matching interface actions. UI uses a coordinated pink, mint, cream,
lavender and deep-plum cartoon palette with standalone functional symbols.

Folder guide
- All_Icons/: all 40 color icons.
- Icons_By_Category/: the same color icons organized by category.
- Grayscale_Icons/All_Icons/: all 40 grayscale variants.
- Grayscale_Icons/Icons_By_Category/: the same grayscale variants by category.
- Documentation/: these three shared documents.

There are 40 unique icon designs, not 160. Color/grayscale are variants;
All_Icons and Icons_By_Category are duplicate organizational views. Choose one
view and the desired variant when importing. Grayscale files preserve the
corresponding color image's filename, size, placement and exact transparency.
See PREVIEW.txt for the exact included names and category folders.

The demo includes one design per category, using the exact color and grayscale
PNG files from the full pack. The full collection contains 360 designs.

Usage
1. Read LICENSE.txt.
2. Import the desired PNGs using your game engine or image tool's workflow.
3. Preserve proportions and transparency when resizing.
4. Assign images to your inventory, candy resources, shops, rewards and UI controls;
   implement your own labels and behavior in your project.

These are static images, not animated sprites, 3D models, scripts or functional
buttons. Game behavior and engine-specific import settings are not included.
Original generic cartoon artwork; no official Roblox affiliation is implied.
